package com.muhammadipublicschool.reportcard;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    // NOTE: Same Apps Script deployment jo Teacher Entry app use karti hai,
    // bas "?view=reportcard" query param se alag (read-only) page load hota hai.
    private static final String URL = "https://script.google.com/macros/s/AKfycbyDNiEQd0tOLU2D2N_3NufVbcSYGcFqXPZisHo1HYKCnKSxPnBEaVBsJAs2MqVL4tbJ/exec?view=reportcard";
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        if (state == null) webView.loadUrl(URL); else webView.restoreState(state);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUserAgentString(s.getUserAgentString() + " MuhammadiReportCardApp/1.0");

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false; // Apps Script navigation app ke andar hi rakhein
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return false; }
        });
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle out) { webView.saveState(out); super.onSaveInstanceState(out); }
}
