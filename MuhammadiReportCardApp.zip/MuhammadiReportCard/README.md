# Muhammadi Report Card — Android App (Chairman/Clerk, read-only)

Yeh alag, standalone app hai — Teacher Entry app se bilkul mukhtalif package
(`com.muhammadipublicschool.reportcard`), taake dono apps ek hi phone par
sath install ho sakein.

Yeh sirf ek lightweight WebView wrapper hai jo Apps Script ke naye
`?view=reportcard` route ko load karta hai. Koi entry/edit ka button nahi hai
— sirf PIN se unlock karke GR No se student ka report card search kiya ja
sakta hai.

## Free APK build
Isi repository mein GitHub Actions workflow shamil hai. Is project ko GitHub
par upload karein aur **Actions → Build Android APK** chalayein. Debug APK
artifact ke tor par milega — koi paid Android build service ki zaroorat
nahi.

## Access
App khulte hi 6-digit access code (PIN) maangega. Sirf sahi PIN dalne ke
baad hi report card search wala screen dikhega.
